Joomla options
=============

Plug-in for managements of built-in libraries Joomla.
Main options: Mootools disable, Jquery disable, Bootstrap disable

Основные опции:

    Отключение Mootools
    Отключение Jquery
    Отключение Bootstrap

Плагин переопределяет классы. Это лучшее решение данных задач

[Download plugin](https://github.com/Poznakomlus/joomla_options/archive/master.zip)
