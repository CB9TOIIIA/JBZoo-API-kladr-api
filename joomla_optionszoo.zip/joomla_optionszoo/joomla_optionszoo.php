<?php
/**
 * @package     Joomla.Plugin
 * @subpackage  System.Joomla_Options
 * @autor       Fedor Vlasenko
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// Запрет прямого доступа.
defined('_JEXEC') or die;

class plgSystemJoomla_Optionszoo extends JPlugin
{

	public function onAfterInitialise()
	{
		// Если мы в админке - выход.
		if (JFactory::getApplication()->isAdmin()) return;
		$basketli = '/basket/';
		if ( preg_match($basketli, $_SERVER[REQUEST_URI])) {
	// Заменяем базовый класс JHtmlBehavior переопределенным
			include 'behavior.php';
		}

	}

}
